close all
snum=1;
lloc='northwest'
doq=1;
doc=1;
dosst=0;
dosst2=0;
dostar=0;
%Vars for plot
%TOA
%vars=[{'netswtoa'},{'olr'}]
%vns=[{,{'Net SW'},{'-OLR'}]

%lab='TOA';

%vars=fliplr([{'tdif'},{'sf'}]);
%vns=fliplr([{'SSTdif (K)'},{'SF'}]);

%docld=0;
dosf=0;
%vars=[{'sf'},{'tdif'}];
%vns=[{'SF'},{'SSTdif'}];
%ylabs=[{'SF'},{'SSTdif (K)'}];
%lloc='northeast'
%dosf=1;

%vars=[{'IWP'},{'LWP'},{'WVP'}];
%vns=[{'IWP'},{'LWP'},{'WVP/1000'}];
%ylabs=[{'Water Path (kg/m^2)'}];
%lloc='east'

%vars=[{'low_cld_amtcold'},{'low_cld_amthot'},{'low_cld_amt'}];
%vns=[{'Low_{cold}'},{'Low_{hot}'},{'Low'}]
%ylabs=[{'Cloud Fraction (%)'}]


%vars=[{'WVPcold'},{'WVPhot'},{'WVP'}];
%vns=[{'WVP_{cold}'},{'WVP_{hot}'},{'WVP'}];
%ylabs=[{'Water Vapor Path (kg/m^2)'}];
%lloc='east'



%vars=[{'tot_cld_amtcold'},{'tot_cld_amthot'},{'tot_cld_amt'}];
%vns=[{'CF_{cold}'},{'CF_{hot}'},{'CF'}]
%ylabs=[{'Total Cloud Fraction (%)'}]
doalbedo=0;
%vars=[{'albedocold'},{'albedohot'},{'albedo'}];
%vns=[{'Albedo_{cold}'},{'Albedo_{hot}'},{'Albedo'}]
%ylabs=[{'Albedo (%)'}]
%doalbedo=1;

%vars=[{'albedodn'},{'albedoup'},{'albedo'}];
%vns=[{'Albedo_{down}'},{'Albedo_{up}'},{'Albedo'}]
%ylabs=[{'Albedo (%)'}]
%vns2=vns;


%dosf=1
%dosst=0;
%dosst2=0;
%dosst2=1
%vars=[{'tlo'}]
%vns=[{'SST_{cold}'}]
%vars=[{'tlo'},{'thi'},{'t_surf'}];
%vns=[{'SST_{cold}'},{'SST_{hot}'},{'SST'}];
%ylabs=[{'SST (K)'}];
%lloc='northwest'
%dosst=0;


%docld=1
%vars=[{'low_cld_amtcold'},{'albedocold'}];
%vns=[{'Low_{cold}'},{'Albedo_{cold}'}];
%ylabs=[{'Low Cloud (%)'},{'Albedo (%)'}];
%lloc='northeast'

doghe=1;
%vars=[{'ghecold'},{'ghehot'},{'ghe'}]
%vns=[{'GHE_{cold}'},{'GHE_{hot}'},{'GHE'}];
%vns2=vns;
%ylabs=[{'GHE (Wm^{-2})'}];

%doghe=0
%vars=[{'ghe_clrcold'},{'ghe_clrhot'},{'ghe_clr'}]
%vns=[{'GHE CLR_{cold}'},{'GHE CLR_{hot}'},{'GHE CLR'}];
%vns2=vns;
%ylabs=[{'GHE CLR (Wm^{-2})'}];

%vars=[{'low_cld_amtcold'},{'high_cld_amtcold'},{'tot_cld_amtcold'}]
%vns=[{'Low_{cold}'},{'High_{cold}'},{'Total_{cold}'}];
%vns2=vns;
%ylabs=[{'Cloud Fraction (%)'}];
%docld=1;

%ylabs=[{'Hot SST Regional Energy Terms'}]
%vars=[{'gmshot'},{'olrhot'},{'netswtoahot'},{'flux_ohhot'}]
%vns=[{'GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]

%ylabs=[{'Cold SST Regional Energy Terms'}]
%`vars=[{'gmscold'},{'olrcold'},{'netswtoacold'},{'flux_ohcold'}]
%vns=[{'GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]
%vns2=vns;
%vars=[{'t_surfdn'},{'t_surfup'},{'t_surf'}];
%vns=[{'SST_{down}'},{'SST_{up}'},{'SST'}];
%ylabs=[{'SST (K)'}];

doereg=0;
%ylabs=[{'Downward Region Energy Terms'}]
%ylabs=[{'Downward Region Energy Terms: Current Regime'}]
%vars=[{'gmsdn'},{'olrdn'},{'netswtoadn'},{'flux_ohdn'}]
%vns=[{'-GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]
%vns2=vns;
%doereg=1;

%ylabs=[{'Upward Region Energy Terms'}]
%vars=[{'gmsup'},{'olrup'},{'netswtoaup'},{'flux_ohup'}]
%vns=[{'-GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]
%vns2=vns;
%doereg=1;


%vars=[{'WVPdn'},{'WVPup'},{'WVP'}];
%vns=[{'WVP_{down}'},{'WVP_{up}'},{'WVP'}];
%ylabs=[{'Water Vapor Path (kg/m^2)'}];
%vns2=vns;
%
%vars=[{'low_cld_amtdn'},{'low_cld_amtup'},{'low_cld_amt'}];
%vns=[{'Low_{down}'},{'Low_{up}'},{'Low'}]
%ylabs=[{'Cloud Fraction (%)'}]
%docld=0;


vars=[{'ghedn'},{'gheup'},{'ghe'}];
vns=[{'GHE_{down}'},{'GHE_{up}'},{'GHE'}];
ylabs=[{'GHE (Wm^{-2})'}];


%vars=[{'ghe_clrdn'},{'ghe_clrup'},{'ghe_clr'}];
%vns=[{'GHE CLR_{down}'},{'GHE CLR_{up}'},{'GHE CLR'}];
%ylabs=[{'GHE CLR (Wm^{-2})'}];
%vns2=vns;
%vars=[{'vpp880dn'},{'vpp880up'},{'vpp880'}];
%vns=[{'VPP_{880,down}'},{'VPP_{880,up}'},{'VPP_{880}'}];
%ylabs=[{'VPP above 880 hPa'}];

%vars=[{'vpp880cold'},{'vpp880hot'},{'vpp880'}];
%vns=[{'VPP_{880,cold}'},{'VPP_{880,hot}'},{'VPP_{880}'}];
%ylabs=[{'VPP above 880 hPa'}];




%vars=[{'olr'},{'thi'}];
%vns=[{'OLR (Wm^{-2})'},{'T_{hot} (K)'}];

%vars=[{'olr'},{'t_surf'}];
%vns=[{'OLR (Wm^{-2})'},{'SST_{up} (K)'}];

%vars=[{'olr'},{'netswtoa'},{'evap'}];
%vns=[{'OLR'},{'NetSW_{TOA}'},{'LE'}];

%vars=[{'olr'},{'netswtoa'}]%,{'evap'}];
%vns=[{'OLR'},{'NetSW_{TOA}'}]%,{'LE'}];

%vars=[{'ghe'},{'swcresfc'}]%,{'evap'}];
%vns=[{'|GHE|'},{'|SWCRE|'}]%,{'LE'}];

%vars=[{'ghe'},{'swcre'}]%,{'evap'}];
%vns=[{'|GHE|'},{'|SWCRE|'}]%,{'LE'}];


%vars=[{'olr'},{'netswtoa'},{'evap'},{'ghe'},{'swcre'}]%,{'evap'}];
;
%vns=[{'OLR'},{'NetSW_{TOA}'},{'LE'},{'|GHE|'},{'|SWCRE|'}]%,{'LE'}];
;

%vars=[{'olr'},{'netswtoa'}]%,{'evap'}];
;
%vns=[{'OLR'},{'NetSW_{TOA}'}]%,{'LE'}];
;

%vars=[{'ghe'},{'swcre'}]%,{'evap'}];
;
%vns=[{'GHE'},{'|SWCRE|'}]%,{'LE'}];

%vars=[{'tlo'},{'thi'}]%,{'evap'}];
;
%vns=[{'SST_{low}'},{'SST_{high}'}]%,{'LE'}];




%vars=[{'olr'},{'gms'}];
%vns=[{'OLR (Wm^{-2})'},{'GMS_{up} (Wm^{-2})'}];

%vars=[{'tlo'},{'thi'}];
%vns=[{'SST_{cold}'},{'SST_{hot}'}];

xvar='swdn_toa'
xlab='Insolation (Wm^{-2})'

%xvar='t_surf'
%xlab='Global Mean SST (K)'

%xvar='thi'
%xlab='SST_{hot} (K)'

%xvar='tlo'
%xlab='SST_{cold} (K)'




%vars=[{'flux_oh'},{'netswtoa'},{'olr'},{'gms'}]
%vns=[{'Qflux'},{'Net SW'},{'-OLR'},{'-GMS'}]
%vars=[{'flux_oh'},{'netswtoa'},{'ghe'},{'gms'}]
%vns=[{'Qflux'},{'Net SW'},{'GHE'},{'-GMS'}]

%lab='SFC';
%vars=[{'flux_oh'},{'netswsfc'},{'netlwsfc'},{'sfcflx'}]
%vns=[{'Qflux'},{'Net SW'},{'Net LW'},{'-Sfc Flx'}]

%Just Qflux Experiments
%casenums=[{'36qflux'},{'36C2'},{'33qflux'},{'33C2'}];
%cns=[{'36Q'},{'36'},{'33Q'},{'33'}];
%qcasenums=[{'36qflux'},{'36C2'},{'33qflux'},{'33C2'},{'30qflux'},{'30C2'},{'26qflux'},{'26C2'}]
%ccasenums=[{'36C2'},{'33C2'},{'30C2'},{'26C2'}]
%qcasenums=[{'36qflux'},{'33qflux'},{'30qflux'},{'26qflux'}]
%ccns=[{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'26C2'}]
%qcns=[{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'26qflux'}]
ccasenums=[{'45C2'},{'44C2'},{'43C2'},{'42C2'},{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'28C2'},{'26C2'}]
qcasenums=[{'42qflux'},{'40qflux'},{'39qflux'},{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'28qflux'},{'265qflux'},{'26qflux'},{'24qflux'}]





%cns=[{'Q301','C304','Q304','C307','Q306','C309','Q313','C319'}];

%X=categorical(cns);
%X=reordercats(X,cns);
cnum=length(ccasenums);
qnum=length(qcasenums);
vnum=length(vars)
%Load data
cvals=zeros(cnum,vnum,1);
qvals=zeros(qnum,vnum,1);
cins=zeros(cnum,1);
qins=zeros(qnum,1);
qerrvals=zeros(qnum,vnum);
cerrvals=zeros(cnum,vnum);



%figure
%hold on
%gradsmap
%box on
%grid on
%set(gca,'fontsize',14)
mind=max(cnum,qnum)
for i=1:mind
        if i<=cnum 
        ccns{i}=newcasenum(ccasenums{i});
%	load(['swdn_toa',casenums{i},'table.mat'],'stuff')
	load([xvar,ccasenums{i},'table.mat'],'stuff')
        cins(i)=stuff(1,1);
        end
        if i<=qnum
        qcns{i}=newcasenum(qcasenums{i});
	load([xvar,qcasenums{i},'table.mat'],'stuff')
        qins(i)=stuff(1,1);
        end
	for j=1:vnum
                if contains(vars{j},'up')
                    snum=2;
                    vj=vars{j}(1:end-2);
                elseif contains(vars{j},'dn')
                    snum=3;
                    vj=vars{j}(1:end-2);
                else
                    snum=1;
                    vj=vars{j};
                end
                if i<=cnum && ~contains(vars{j},'flux_oh')
                cerrvals(i,j)=getdf(ccasenums{i},vj,0);
		load([vj,ccasenums{i},'table.mat'],'stuff')
		if (strcmp(vj,'gms') || contains(vj,'swcre'))
			stuff=-1*stuff;
                elseif contains(vj,'albedo')
                     stuff=stuff*100;
%		elseif contains(vj,'WVP')
%	             stuff=stuff/1000;
		end
		cvals(i,j,1)=stuff(1,snum);
                end
                if i<=qnum
		load([vj,qcasenums{i},'table.mat'],'stuff')
		if (strcmp(vj,'gms') ||contains(vj,'swcre'))
			stuff=-1*stuff;
                elseif contains(vj,'albedo')
                     stuff=stuff*100;
%		elseif contains(vj,'WVP')
%	             stuff=stuff/1000;
		end
		qvals(i,j,1)=stuff(1,snum);
                qerrvals(i,j)=getdf(qcasenums{i},vj,0);
                end

        end
end


figure
hold on
a=get(gca,'colororder');
if dosst
a(3,:,:)=[0,0,0];
elseif dosst2
	a(1,:,:)=a(1,:,:);
        a(3,:,:)=[0,0,0];
end
box on
grid on
grid on
set(gca,'layer','top');
set(gca,'fontsize',14,'LineWidth',1.5)
for ii=1:vnum
     ylabel(ylabs(1))
 
if dosf
    if ii==1
        yyaxis left
        ylim([0.5 1])
    else
        yyaxis right
        ylim([0 14])
        ylabel(ylabs{ii})

    end
end
if docld
    if ii==1
        yyaxis left
        ylim([10 80])
    else
        yyaxis right
        ylim([10 80])
         ylabel(ylabs{ii})
    end
end
if doalbedo
	ylim([10 70])
end
if doq
    errorbar(qins,squeeze(qvals(:,ii,1)),qerrvals(:,ii),'-','color',a(ii,:),'LineWidth',1.5,'DisplayName',vns{ii})
    scatter(qins,squeeze(qvals(:,ii,1)),50,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
end
if doc
    errorbar(cins,squeeze(cvals(:,ii,1)),cerrvals(:,ii),'--','color',a(ii,:),'LineWidth',1.5,'HandleVisibility','off')

    scatter(cins,squeeze(cvals(:,ii,1)),50,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')%'DisplayName',['Q',vns{ii}])
end
    if dosst
    scatter([cins(3),qins(3)],[cvals(3,3),qvals(3,3)],200,'filled','Marker','pentagram','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerFaceAlpha',1,'HandleVisibility','off')
    scatter([cins(8),qins(8)],[cvals(8,3),qvals(8,3)],200,'filled','Marker','pentagram','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerFaceAlpha',1,'HandleVisibility','off')
   ylim([275 325]) 
    elseif dostar && ii==2
        scatter([cins(3),qins(2)],[cvals(3,2),qvals(2,2)],200,'filled','Marker','pentagram','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerFaceAlpha',1,'HandleVisibility','off')
        scatter([cins(8),qins(7)],[cvals(8,2),qvals(7,2)],200,'filled','Marker','pentagram','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerFaceAlpha',1,'HandleVisibility','off')
 
   end
end
xlabel(xlab)
if doghe
%    ylim([70 400])
    ylim([90 360])
end
if doereg
    ylim([-70 370])
end
if dosst2
	ylim([270 325])
end
%legend('color','none','box','off','location','southeast')
%legend('color','none','box','off','location','east')

%legend('color','none','box','off','location','northeast')
legend('color','none','box','off','location',lloc)
%lloc='east'
%legend('color','none','box','off','location',lloc)

%legend('color','none','box','off','location','northwest')
xlim([305 400])
%saveas(gcf,'tdifsoht.png')
svpdf('tdifsfoht.pdf')
   

