ccasenums=[{'45C2'},{'44C2'},{'43C2'},{'42C2'},{'40C2'},{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'28C2'},{'26C2'}];
qcasenums=[{'42qflux'},{'40qflux'},{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'28qflux'},{'265qflux'},{'26qflux'},{'24qflux'}];
cnum=length(ccasenums);
qnum=length(qcasenums);
cvals=zeros(cnum-1,1);
qvals=zeros(qnum-1,1);
size(qvals)
cins=zeros(cnum,1);
qins=zeros(qnum,1);
csst=zeros(cnum,1);
qsst=zeros(qnum,1);

xvar2='t_surf'
xvar='swdn_toa'
for i=1:cnum+1
        if i<=cnum
		ccns{i}=newcasenum(ccasenums{i});
	%       load(['swdn_toa',casenums{i},'table.mat'],'stuff')
		load([xvar,ccasenums{i},'table.mat'],'stuff')
		cins(i)=stuff(1,1);
		load([xvar2,ccasenums{i},'table.mat'],'stuff')
		csst(i)=stuff(1,1);
		if i>1
                    cvals(i-1)=(csst(i)-csst(i-1))/(cins(i)-cins(i-1));
		end
	end
        if i<=qnum
        qcns{i}=newcasenum(qcasenums{i});
        load([xvar,qcasenums{i},'table.mat'],'stuff')
        qins(i)=stuff(1,1);
        load([xvar2,qcasenums{i},'table.mat'],'stuff')
        qsst(i)=stuff(1,1);
        if i>1
            qvals(i-1)=(qsst(i)-qsst(i-1))/(qins(i)-qins(i-1));
        end
        end
end

figure
hold on
a=get(gca,'colororder');
box on
grid on
ii=1;
ij=2;
set(gca,'fontsize',14,'LineWidth',1.5)
plot(qins(2:end),qvals,'-','color',a(ii,:),'LineWidth',1.5,'DisplayName','Qflux')
scatter(qins(2:end),qvals,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
plot(cins(2:end),cvals,'--','color',a(ij,:),'LineWidth',1.5,'DisplayName','Ctl')
scatter(cins(2:end),cvals,50,'filled','MarkerEdgeColor',a(ij,:),'MarkerFaceColor',a(ij,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
ylabel('Sensitivity (K/(Wm^{-2}))')
legend('color','none','box','off','location','northeast')
%svpdf('qfluxfeedback.pdf')
hold off

figure
hold on
a=get(gca,'colororder');
box on
grid on
ii=1;
ij=2;
set(gca,'fontsize',14,'LineWidth',1.5)
plot(qins,qsst,'-','color',a(ii,:),'LineWidth',1.5,'DisplayName','Qflux')
scatter(qins,qsst,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
plot(cins,csst,'--','color',a(ij,:),'LineWidth',1.5,'DisplayName','Ctl')
scatter(cins,csst,50,'filled','MarkerEdgeColor',a(ij,:),'MarkerFaceColor',a(ij,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
ylabel('SST (K)')
xlabel('Insolation (Wm^{-2})')
legend('color','none','box','off','location','northeast')
%svpdf('qfluxfeedback.pdf')
hold off


figure
hold on
a=get(gca,'colororder');
box on
grid on
ii=1;
ij=2;
set(gca,'fontsize',14,'LineWidth',1.5)
yyaxis left
plot(qins,qsst,'-','color',a(ii,:),'LineWidth',1.5,'DisplayName','Q-SST')
scatter(qins,qsst,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
plot(cins,csst,'--','color',a(ii,:),'LineWidth',1.5,'DisplayName','C-SST')
scatter(cins,csst,50,'filled','MarkerEdgeColor',a(ii,:),'MarkerFaceColor',a(ii,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
ylabel('SST (K)')
xlabel('Insolation (Wm^{-2})')
yyaxis right
plot(qins(2:end),qvals,'-','color',a(ij,:),'LineWidth',1.5,'DisplayName','Q-S')
scatter(qins(2:end),qvals,'filled','MarkerEdgeColor',a(ij,:),'MarkerFaceColor',a(ij,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
plot(cins(2:end),cvals,'--','color',a(ij,:),'LineWidth',1.5,'DisplayName','C-S')
scatter(cins(2:end),cvals,50,'filled','MarkerEdgeColor',a(ij,:),'MarkerFaceColor',a(ij,:),'MarkerFaceAlpha',0.5,'HandleVisibility','off')
ylabel('Sensitivity (K/(Wm^{-2}))')

legend('color','none','box','off','location','northwest')
svpdf('qfluxfeedback.pdf')
hold off


