%newest
%close all

lloc='south'
%Vars for plot
%TOA
%vars=[{'netswtoa'},{'olr'}]
%vns=[{,{'Net SW'},{'-OLR'}]
ylabs='Regional Energy Changes';
%lab='TOA';

%vars=fliplr([{'tdif'},{'sf'}]);
%vns=fliplr([{'SSTdif (K)'},{'SF'}]);

%vars=[{'olr'},{'thi'}];
%vns=[{'OLR (Wm^{-2})'},{'T_{hot} (K)'}];

%vars=[{'olr'},{'t_surf'}];
%vns=[{'OLR (Wm^{-2})'},{'SST_{up} (K)'}];


gud1=1;
gud2=1;


%vars=[{'olr'},{'gms'}];
%vns=[{'OLR (Wm^{-2})'},{'GMS_{up} (Wm^{-2})'}];
%sreg=' Hot Region'
%lloc='south'
%vars=[{'gmshot'},{'olrhot'},{'netswtoahot'},{'flux_ohhot'}]
%vns=[{'GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]

%sreg=' Downward Region'
%sreg=' Downward Region: Current Regime'
%vars=[{'gms'},{'olr'},{'netswtoa'},{'flux_oh'}]
%vns=[{'-GMS'},{'-OLR'},{'NetSW_{toa}'},{'Qflux'}]
%vns2=[{'-GMS','-OLR','NetSW_{toa}','Qflux'}]
%vars=[{'albedo'},{'low_cld_amt'},{'tot_cld_amt'}]
%vns2=[{'Albedo,' 'Low Cloud','Total Cloud'}]

gud2=3; %down
%vars=[{'swcre'},{'lwcre'},{'netcre'}];
%vns=[{'SWCRE'},{'LWCRE'},{'NetCRE'}];
%vns2=[{'SWCRE','LWCRE','NetCRE'}];
%vars=[{'LWP'},{'IWP'}]%,{'WVPhot'}]
%vns=[{'LWP'},{'IWP'}]%,{'WVP'}]
%vns2=[{'LWP', 'IWP'}]%,'WVP'}]
%ylabs='Water Path'
%vars=[{'low_cld_amt'},{'high_cld_amt'},{'tot_cld_amt'}]
%vns=[{'Low'},{'High'},{'Total'}]
%vns2=[{'Low','High','Total'}]

sreg=' Upward Region'
vars=[{'gms'},{'olr'},{'netswtoa'},{'flux_oh'}]
vns=[{'-GMS'},{'-OLR'},{'NetSW_{toa}'},{'Qflux'}]
vns2=[{'-GMS','-OLR','NetSW_{toa}','Qflux'}]
gud2=2;


%vars=[{'olr'},{'lwup_sfc'},{'falwup'}];
%vns=[{'OLR'},{'F_{up,sfc}'},{'F_{A,up}'}];
%vns2=[{'OLR','F_{up,sfc}','F_{A,up}'}];

%vars=[{'olr'},{'lwflx'},{'falw'}];
%vns=[{'OLR'},{'F_{0}'},{'F_{A}'}];
%vns2=[{'OLR','F_{0}','F_{A}'}];
%gud2=3; %down

%sreg=' Upward Region'
%lloc='north'
%vars=[{'olr'},{'lwflx'},{'falw'}];
%vns=[{'OLR'},{'F_{0}'},{'F_{A}'}];
%vns2=[{'OLR','F_{0}','F_{A}'}];
%gud2=2; %up

%sreg=' Cold Region'
%lloc='north'
%vars=[{'gmscold'},{'olrcold'},{'netswtoacold'},{'flux_ohcold'}]
%vns=[{'GMS'},{'OLR'},{'NetSW_{toa}'},{'Qflux'}]
%vars=[{'lwup_sfccold'},{'lwdn_sfccold'},{'lwflxcold'},{'falwcold'},{'ghecold'},{'olrcold'}]
%vns=[{'LW_{up,sfc}'},{'LW_{dn,sfc}'},{'NetLW'},{'F_{A}'},{'GHE'},{'OLR'}];

%vars=[{'olrcold'},{'netswtoacold'},{'gmscold'},{'flux_ohcold'}]
%vns=[{'OLR'},{'NetSW_{toa}'},{'GMS'},{'Qflux'}]


%vars=[{'t_surf'},{'sf'},{'tdif'}];
%vns=[{'GMSST (K)'},{'SF'},{'SSTdif (K)'}]
%vns=[{'SST_{up} (K)'},{'GMS_{up} (Wm^{-2})'}];

svnm='delta2.png'

%vars=[{'tlo'},{'thi'}];
%vns=[{'SST_{cold}'},{'SST_{hot}'}];



xvar='swdn_toa'
xlab='Insolation (Wm^{-2})'

%xvar='t_surf'
%xlab='Global Mean SST (K)'

%xvar='thi'
%xlab='SST_{hot} (K)'



%vars=[{'flux_oh'},{'netswtoa'},{'olr'},{'gms'}]
%vns=[{'Qflux'},{'Net SW'},{'-OLR'},{'-GMS'}]
%vars=[{'flux_oh'},{'netswtoa'},{'ghe'},{'gms'}]
%vns=[{'Qflux'},{'Net SW'},{'GHE'},{'-GMS'}]

%lab='SFC';
%vars=[{'flux_oh'},{'netswsfc'},{'netlwsfc'},{'sfcflx'}]
%vns=[{'Qflux'},{'Net SW'},{'Net LW'},{'-Sfc Flx'}]

%Just Qflux Experiments
%casenums=[{'36qflux'},{'36C2'},{'33qflux'},{'33C2'}];
%cns=[{'36Q'},{'36'},{'33Q'},{'33'}];
%qcasenums=[{'36qflux'},{'36C2'},{'33qflux'},{'33C2'},{'30qflux'},{'30C2'},{'26qflux'},{'26C2'}]
%ccasenums=[{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'28C2'},{'26C2'}]
%qcasenums=[{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'28qflux'},{'26qflux'}]
%ccns=[{'36C2'},{'33C2'},{'30C2'},{'26C2'}]
%qcns=[{'36qflux'},{'33qflux'},{'30qflux'},{'26qflux'}]
ccasenums=[{'42C2'},{'40C2'},{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'28C2'},{'26C2'}]
qcasenums=[{'42qflux'},{'40qflux'},{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'28qflux'},{'26qflux'}]
ccns=[{'42C2'},{'40C2'},{'38C2'},{'36C2'},{'33C2'},{'30C2'},{'26C2'}]
qcns=[{'42qflux'},{'40qflux'},{'38qflux'},{'36qflux'},{'33qflux'},{'30qflux'},{'26qflux'}]

%cns=[{'Q301','C304','Q304','C307','Q306','C309','Q313','C319'}];

%X=categorical(cns);
%X=reordercats(X,cns);
cnum=length(ccasenums);
vnum=length(vars)
%Load data
cvals=zeros(cnum,vnum,3);
qvals=zeros(cnum,vnum,3);
cins=zeros(cnum,1);
qins=zeros(cnum,1);

for i=1:cnum
        ccns{i}=newcasenum(ccasenums{i})
%	load(['swdn_toa',casenums{i},'table.mat'],'stuff')
	load([xvar,ccasenums{i},'table.mat'],'stuff')
        cins(i)=stuff(1,1);
        qcns{i}=newcasenum(qcasenums{i})
	load([xvar,qcasenums{i},'table.mat'],'stuff')
        qins(i)=stuff(1,1);
	for j=1:vnum
                if ~contains(vars{j},'flux_oh')
   		load([vars{j},ccasenums{i},'table.mat'],'stuff')
		cvals(i,j,1:3)=stuff;
                end
		load([vars{j},qcasenums{i},'table.mat'],'stuff')
		qvals(i,j,1:3)=stuff;
                if strcmp(vars{j},'albedo')
                    qvals(i,j,1:3)=100*qvals(i,j,1:3);
                    cvals(i,j,1:3)=100*cvals(i,j,1:3);
		elseif contains(vars{j},'gms') || contains(vars{j},'olr')
                    qvals(i,j,1:3)=-1*qvals(i,j,1:3);
                    cvals(i,j,1:3)=-1*cvals(i,j,1:3);
                end

end
end


a=get(gca,'colororder');
%a(3,:) = ai(
%Difference between qflux and ctl
delta=qvals-cvals;

%Plot data
fig=figure
hold on
gradsmap
sz=50
left_color = a(1,:);%[.5 .5 0];
right_color = a(2,:);%[0 .5 .5];
set(gca,'fontsize',14)
box on 
grid on
set(gca,'defaultAxesColorOrder',[left_color; right_color]);
%yyaxis left

a=get(gca,'colororder');
for i=1:1
%plot(cins(:,1),delta(:,i,gud2),'-','color',a(i,:),'LineWidth',1.5,'DisplayName',vns{i})%
b=bar(cins(:,1),delta(:,:,gud2))
xticks(round(cins(:,1)))
%set(b,{'DisplayName'},{'GMS','OLR','NetSW_{toa}','Qflux'}')
set(b,{'DisplayName'},vns2');

%scatter(cins(:,1),delta(:,i,gud2),sz,'filled','MarkerFaceColor',a(i,:),'HandleVisibility','off')
end
%scatter(qins(:,1),qvals(:,1,gud1),sz,'filled','MarkerFaceColor',left_color,'HandleVisibility','off')

%ylabel(['Qflux-Ctl ',vns{1}])
%ylabel('Regional Energy Changes')
ylabel(ylabs)
%yyaxis right

%plot(qins(:,1),qvals(:,2,gud2),'k--','LineWidth',1.5,'HandleVisibility','off','HandleVisibility','off')
%scatter(qins(:,1),qvals(:,2,gud2),sz,'filled','MarkerFaceColor',right_color,'HandleVisibility','off')

%ylabel(['Qflux-Ctl ',vns{2}])
title(['Qflux - Ctl',sreg])
%legend('location','east')
xlabel(xlab)
%lloc='southwest'
%lloc='northwest'
%legend('location',lloc,'color','none','box','off')
pbaspect([1.4 1 1]);
%ylim([-60 60])
%ylim([-80 40])
xlim([320 400])
%xlim([345 395])
saveas(gca,svnm)
uploadToDropbox(svnm)
svpdf('delta.pdf')
